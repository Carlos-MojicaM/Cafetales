const Cafetal = artifacts.require("Cafetal");

contract("Cafetal", (accounts) => {
  it("should register a user", async () => {
    const instance = await Cafetal.deployed();
    await instance.registerUser("Carlos", "carlos@example.com", { from: accounts[0] });
    const user = await instance.getUser(accounts[0]);
    assert.equal(user[0], "Carlos");
    assert.equal(user[1], "carlos@example.com");
  });
});
