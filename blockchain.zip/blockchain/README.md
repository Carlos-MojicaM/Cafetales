# Cafetal Blockchain

Contrato inteligente para registro de usuarios.

## Comandos

- `npm install`
- `truffle migrate --reset`
- `truffle test`
