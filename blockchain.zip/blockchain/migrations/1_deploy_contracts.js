const Cafetal = artifacts.require("Cafetal");

module.exports = function (deployer) {
  deployer.deploy(Cafetal);
};
