const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('../models/User'); // Asegúrate que este modelo existe
const connectDB = require('../config/db');

dotenv.config();
connectDB();

const seedUsers = async () => {
  try {
    await User.deleteMany();

    await User.insertMany([
      {
        name: 'Admin Cafetal',
        email: 'admin@cafetal.com',
        password: '123456', // hash automático si usas bcrypt en pre-save
        role: 'admin',
      },
      {
        name: 'Usuario Cafetal',
        email: 'user@cafetal.com',
        password: '123456',
        role: 'buyer',
      },
    ]);

    console.log('✅ Usuarios de prueba insertados');
    process.exit();
  } catch (error) {
    console.error('❌ Error en seeders', error);
    process.exit(1);
  }
};

seedUsers();
