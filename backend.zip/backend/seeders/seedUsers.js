const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('../models/userModel');
const connectDB = require('../config/db');

dotenv.config();
connectDB();

const seedUsers = async () => {
  try {
    await User.deleteMany();
    await User.create([
      { name: 'Admin', email: 'admin@cafetal.com', password: 'admin123' },
      { name: 'User', email: 'user@cafetal.com', password: 'user123' },
    ]);
    console.log('Usuarios insertados');
    process.exit();
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
};

seedUsers();
