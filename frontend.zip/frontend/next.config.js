// Placeholder for next.config.js
