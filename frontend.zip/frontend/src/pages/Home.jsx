import Header from '../components/Header';

function Home() {
  return (
    <div>
      <Header />
      <h2>Bienvenido a Cafetal</h2>
    </div>
  );
}

export default Home;
