import axios from 'axios';

export const registerUser = async (userData) => {
  try {
    const res = await axios.post(import.meta.env.VITE_API_URL + '/api/users', userData);
    console.log(res.data);
    alert('Usuario registrado!');
  } catch (error) {
    console.error(error.response.data);
    alert('Error al registrar');
  }
};
